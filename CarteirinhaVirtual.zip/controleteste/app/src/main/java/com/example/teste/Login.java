package com.example.teste;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {
    EditText edtEmail;
    EditText edtSenha;
    SQLiteDatabase bancoDados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        edtEmail = findViewById(R.id.edtEmailLogin);
        edtSenha = findViewById(R.id.edtSenhaLogin);

        // Abra o banco de dados para leitura ou cria se não existir
        bancoDados = openOrCreateDatabase("carteirinhabanco", MODE_PRIVATE, null);

        // Certifique-se de que a tabela "alunos" exista no banco de dados
        bancoDados.execSQL("CREATE TABLE IF NOT EXISTS alunos (id INTEGER PRIMARY KEY, nome TEXT, email TEXT, senha TEXT)");
    }

    public void verificarLogin(View view) {
        String email = edtEmail.getText().toString();
        String senha = edtSenha.getText().toString();

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(senha)) {
            Toast.makeText(this, "Por favor, preencha todos os campos", Toast.LENGTH_SHORT).show();
            return;
        }

        int idAluno = 0;
        String nomeAluno = "";
        String emailAluno = "";
        String imagemAluno = "";

        // Consulta o banco de dados para verificar o login
        Cursor cursor = bancoDados.rawQuery("SELECT id, nome, email, nome_imagem FROM alunos WHERE email = ? AND senha = ?", new String[]{email, senha});

        if (cursor.moveToFirst()) {
            // Login bem-sucedido
            int idColumnIndex = cursor.getColumnIndex("id");
            int nomeColumnIndex = cursor.getColumnIndex("nome");
            int emailColumnIndex = cursor.getColumnIndex("email");
            int nomeImagemColumnIndex = cursor.getColumnIndex("nome_imagem");

            idAluno = cursor.getInt(idColumnIndex);
            nomeAluno = cursor.getString(nomeColumnIndex);
            emailAluno = cursor.getString(emailColumnIndex);
            imagemAluno = cursor.getString(nomeImagemColumnIndex);

            cursor.close();

            // Crie um Intent para a atividade QRCode
            Intent intent = new Intent(this, QRCode.class);
            intent.putExtra("idAluno", idAluno);
            intent.putExtra("nomeAluno", nomeAluno);
            intent.putExtra("emailAluno", emailAluno);
            intent.putExtra("imagemAluno", imagemAluno);
            startActivity(intent);
        } else {
            // Login mal-sucedido
            cursor.close();
            Toast.makeText(this, "Email ou senha incorretos", Toast.LENGTH_SHORT).show();
        }

        cursor.close();
    }

    public void voltarParaMainActivity(View view) {
        // Intent para voltar ao MainActivity
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        // Feche o banco de dados quando a atividade for destruída
        if (bancoDados != null) {
            bancoDados.close();
        }
    }
}
