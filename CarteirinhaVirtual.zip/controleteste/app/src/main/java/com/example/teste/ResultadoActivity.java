package com.example.teste;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

import de.hdodenhof.circleimageview.CircleImageView;

public class ResultadoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado);

        String nomeAluno = getIntent().getStringExtra("nomeAluno");
        String emailAluno = getIntent().getStringExtra("emailAluno");
        int idAluno = getIntent().getIntExtra("idAluno", 0);
        String imagemAluno = getIntent().getStringExtra("imagemAluno"); // Recupere o nome da imagem do usuário

        TextView textViewNome = findViewById(R.id.textViewNome);
        TextView textViewEmail = findViewById(R.id.textViewEmail);
        TextView textViewId = findViewById(R.id.idTextView);

        textViewNome.setText("Nome do Aluno: " + nomeAluno);
        textViewEmail.setText("Email do Aluno: " + emailAluno);
        textViewId.setText("ID do Aluno: " + idAluno);

        // Recupere a data e hora do escaneamento do Intent
        String dataEscaneamento = getIntent().getStringExtra("dataEscaneamento");

        TextView textViewDataHora = findViewById(R.id.textViewDataHora);
        textViewDataHora.setText("Data e Hora: " + dataEscaneamento);

        // Encontre o TextView que contém "Código Verificado"
        TextView textViewCodigoVerificado = findViewById(R.id.textViewCodigoVerificado);

        // Texto completo
        String textoCompleto = textViewCodigoVerificado.getText().toString();

        // Crie uma SpannableString
        SpannableString spannableString = new SpannableString(textoCompleto);

        // Defina a cor verde para a parte "Código Verificado"
        int start = textoCompleto.indexOf("Código Verificado");
        int end = start + "Código Verificado".length();
        spannableString.setSpan(new ForegroundColorSpan(getResources().getColor(android.R.color.holo_green_light)), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        // Aplique a SpannableString ao TextView
        textViewCodigoVerificado.setText(spannableString);

        // Configure o clique no botão "Registros"
        Button buttonRegistros = findViewById(R.id.button2);
        buttonRegistros.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Quando o botão "Registros" é clicado, inicie a ListaDataHoraEscaneamento
                Intent intent = new Intent(ResultadoActivity.this, ListaDataHoraEscaneamento.class);
                intent.putExtra("idAlunoSelecionado", idAluno); // Passe o ID do aluno
                startActivity(intent);
            }
        });

        // Carregue a imagem do usuário
        CircleImageView fotoperfilResultado = findViewById(R.id.fotoperfil_resultado);
        exibirImagemPerfil(imagemAluno, fotoperfilResultado);
    }

    private void exibirImagemPerfil(String nomeImagem, CircleImageView circleImageView) {
        if (!TextUtils.isEmpty(nomeImagem)) {
            // O caminho da imagem deve ser o mesmo que você usou para salvar a imagem
            String caminhoImagem = getExternalFilesDir(Environment.DIRECTORY_PICTURES) + File.separator + nomeImagem;

            // Carregue a imagem do caminho e exiba-a no CircleImageView
            File imagemArquivo = new File(caminhoImagem);

            if (imagemArquivo.exists()) {
                Uri imagemUri = Uri.fromFile(imagemArquivo);
                circleImageView.setImageURI(imagemUri);
            } else {
                Toast.makeText(this, "Imagem do usuário não encontrada", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Nome da imagem do usuário vazio", Toast.LENGTH_SHORT).show();
        }
    }
}
