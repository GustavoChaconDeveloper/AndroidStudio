package com.example.teste;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.content.Intent;
import android.Manifest;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Registro extends AppCompatActivity {

    private SQLiteDatabase bancoDados;
    EditText edtNome;
    EditText edtCurso;
    EditText edtEmail;
    Spinner spinnerPeriodo;
    EditText edtSenha;
    private ImageView photoImageView;
    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private File imageFile; // Variável para armazenar o arquivo da imagem

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        edtNome = findViewById(R.id.edtNomeRegistro);
        edtCurso = findViewById(R.id.edtSenhaLogin);
        edtEmail = findViewById(R.id.edtEmailLogin);
        spinnerPeriodo = findViewById(R.id.spinnerPeriodo);
        edtSenha = findViewById(R.id.edtSenhaRegistro);
        photoImageView = findViewById(R.id.fotoperfil);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapter.add("Matutino");
        adapter.add("Vespertino");
        adapter.add("Noturno");

        spinnerPeriodo.setAdapter(adapter);

        // Solicitar permissões em tempo de execução
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
            }
        }
    }

    public boolean verificarVazio() {
        boolean camposVazios = TextUtils.isEmpty(edtNome.getText().toString()) ||
                TextUtils.isEmpty(edtCurso.getText().toString()) ||
                TextUtils.isEmpty(edtEmail.getText().toString()) ||
                TextUtils.isEmpty(edtSenha.getText().toString());
        return camposVazios;
    }

    public void tirarFoto(View view) {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            try {
                imageFile = criarArquivoDaImagem();
                if (imageFile != null) {
                    Uri photoURI = FileProvider.getUriForFile(this, "com.example.teste.fileprovider", imageFile);
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                    startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private File criarArquivoDaImagem() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String imageFileName = "JPEG_" + timeStamp;
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(imageFileName, ".jpg", storageDir);

        // Exibir o caminho do arquivo de imagem em um Toast
        Toast.makeText(this, "Caminho do arquivo de imagem: " + image.getAbsolutePath(), Toast.LENGTH_LONG).show();

        return image;
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            if (imageFile != null) {
                // Exibir a imagem no ImageView
                photoImageView.setImageURI(Uri.fromFile(imageFile));
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED &&
                    grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                // Permissões concedidas, agora você pode tirar fotos.
            } else {
                Toast.makeText(this, "Permissões não concedidas. Você não pode tirar fotos.", Toast.LENGTH_SHORT).show();
            }
        }
    }


    public void cadastrarBanco(View view) {
        if (verificarVazio()) {
            Toast.makeText(this, "Preencha todos os campos antes de cadastrar", Toast.LENGTH_SHORT).show();
        } else if (imageFile == null) {
            Toast.makeText(this, "Tire uma foto antes de cadastrar", Toast.LENGTH_SHORT).show();
        } else {
            try {
                bancoDados = openOrCreateDatabase("carteirinhabanco", MODE_PRIVATE, null);
                String sql = "INSERT INTO alunos (nome, email, senha, curso, periodo, nome_imagem) VALUES (?, ?, ?, ?, ?, ?)";
                SQLiteStatement stmt = bancoDados.compileStatement(sql);
                stmt.bindString(1, edtNome.getText().toString());
                stmt.bindString(2, edtEmail.getText().toString());
                stmt.bindString(3, edtSenha.getText().toString());
                stmt.bindString(4, edtCurso.getText().toString());
                stmt.bindString(5, spinnerPeriodo.getSelectedItem().toString());

                // Adicione o nome da imagem ao SQL
                String nomeImagem = imageFile.getName();
                stmt.bindString(6, nomeImagem);

                stmt.executeInsert();
                bancoDados.close();
                Toast.makeText(this, "Cadastrado com sucesso no banco!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, Login.class);
                startActivity(intent);
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Erro ao cadastrar no banco!", Toast.LENGTH_SHORT).show();
            }
        }
    }
    public void voltarParaMainActivity2(View view) {
        // Intent para voltar ao MainActivity
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }


}