package com.example.teste;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class ListaDataHoraEscaneamento extends AppCompatActivity {

    private SQLiteDatabase bancoDados;
    private ListView listViewDataHora;
    private int idAlunoSelecionado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_data_hora_escaneamento);
        listViewDataHora = findViewById(R.id.listViewDataHora);

        // Obtenha o ID do aluno selecionado da Intent
        idAlunoSelecionado = getIntent().getIntExtra("idAlunoSelecionado", 0);

        // Inicialize o banco de dados
        bancoDados = openOrCreateDatabase("carteirinhabanco", MODE_PRIVATE, null);

        // Liste os dados de data e hora de escaneamento para o aluno selecionado
        listarDataHoraEscaneamento(idAlunoSelecionado);
    }

    // Método para listar os dados de data e hora de escaneamento para o aluno selecionado
    private void listarDataHoraEscaneamento(int idAluno) {
        // Consulta SQL para obter todas as datas e horas de escaneamento para o aluno específico
        String query = "SELECT data_escaneamento FROM pins WHERE aluno_id = ?";

        // Execute a consulta com o ID do aluno
        Cursor cursor = bancoDados.rawQuery(query, new String[]{String.valueOf(idAluno)});

        ArrayList<String> listaDataHora = new ArrayList<>();

        if (cursor.moveToFirst()) {
            do {
                String dataHoraEscaneamento = cursor.getString(cursor.getColumnIndex("data_escaneamento"));
                listaDataHora.add(dataHoraEscaneamento);
            } while (cursor.moveToNext());
        }

        cursor.close();

        // Agora você tem a lista de datas e horas, você pode exibi-las em um ListView
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listaDataHora);
        listViewDataHora.setAdapter(adapter);
    }

    // Método chamado quando o botão "Início" é clicado
    public void irParaMainActivity(View view) {
        // Crie uma Intent para iniciar a MainActivity
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
