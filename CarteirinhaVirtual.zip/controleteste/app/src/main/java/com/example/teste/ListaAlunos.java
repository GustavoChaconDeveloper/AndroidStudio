package com.example.teste;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class ListaAlunos extends AppCompatActivity {

    private SQLiteDatabase bancoDados;
    public ListView listViewDados;
    public ArrayList<Integer> arrayIds;
    public Integer idSelecionado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_alunos);
        listViewDados = findViewById(R.id.listViewAlunos);
        this.listarDados();

        listViewDados.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Quando um aluno é selecionado na lista, obtenha o ID do aluno
                int idAlunoSelecionado = arrayIds.get(position);

                // Inicie a atividade que exibe a lista de data e hora de escaneamento
                Intent intent = new Intent(ListaAlunos.this, ListaDataHoraEscaneamento.class);
                intent.putExtra("idAlunoSelecionado", idAlunoSelecionado);
                startActivity(intent);
            }
        });
    }
    public void listarDados() {
        try {
            arrayIds = new ArrayList<>();
            bancoDados = openOrCreateDatabase("carteirinhabanco", MODE_PRIVATE, null);
            Cursor meuCursor = bancoDados.rawQuery("SELECT id, nome, email, senha, nome_imagem FROM alunos", null);
            ArrayList<String> linhas = new ArrayList<String>();
            ArrayAdapter meuAdapter = new ArrayAdapter<String>(
                    this,
                    android.R.layout.simple_list_item_1,
                    android.R.id.text1,
                    linhas
            );
            listViewDados.setAdapter(meuAdapter);

            while (meuCursor.moveToNext()) {
                int id = meuCursor.getInt(0);
                String nome = meuCursor.getString(1);
                String email = meuCursor.getString(2);
                String senha = meuCursor.getString(3);
                String alunoInfo = "ID: " + id + ", Nome: " + nome + ", Email: " + email + ", Senha: " + senha;
                linhas.add(alunoInfo);
                arrayIds.add(id);
            }
            meuCursor.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void voltarParaMainActivity3(View view) {
        // Intent para voltar ao MainActivity
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}