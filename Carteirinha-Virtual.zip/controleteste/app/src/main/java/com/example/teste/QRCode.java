package com.example.teste;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import de.hdodenhof.circleimageview.CircleImageView;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class QRCode extends AppCompatActivity {

    private String generatedPin;
    private String nomeAluno;
    private String emailAluno;

    private String imagemAluno;
    private CircleImageView fotoperfil; // Declare a variável fotoperfil

    private int idAluno;
    private SQLiteDatabase bancoDados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrcode);
        generatedPin = generateRandomPin();
        generateQR(generatedPin);

        // Recupere os dados do aluno que foram passados pelo Intent
        Intent intent = getIntent();
        idAluno = intent.getIntExtra("idAluno", 0);
        nomeAluno = intent.getStringExtra("nomeAluno");
        emailAluno = intent.getStringExtra("emailAluno");
        imagemAluno = intent.getStringExtra("imagemAluno"); // Recupere o nome da imagem do aluno

        // Inicialize o banco de dados
        bancoDados = openOrCreateDatabase("carteirinhabanco", MODE_PRIVATE, null);

        fotoperfil = findViewById(R.id.fotoperfil_qrcode);

        // Exiba a imagem do perfil do aluno
        exibirImagemPerfil();
    }

    private String generateRandomPin() {
        Random random = new Random();
        int pin = 1000 + random.nextInt(9000); // Gere um número aleatório de 1000 a 9999
        return String.valueOf(pin);
    }

    private void generateQR(String pin) {
        QRCodeWriter qrCodeWriter = new QRCodeWriter();
        try {
            BitMatrix bitMatrix = qrCodeWriter.encode(pin, BarcodeFormat.QR_CODE, 400, 400);

            // Defina um fundo transparente
            int width = bitMatrix.getWidth();
            int height = bitMatrix.getHeight();
            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);

            for (int x = 0; x < width; x++) {
                for (int y = 0; y < height; y++) {
                    if (bitMatrix.get(x, y)) {
                        bitmap.setPixel(x, y, 0xFFFFFFFF); // Pixel preto (transparente)
                    } else {
                        bitmap.setPixel(x, y, 0x00000000); // Pixel transparente
                    }
                }
            }

            ImageView qrCodeImageView = findViewById(R.id.qrCodeImageView);
            qrCodeImageView.setImageBitmap(bitmap);
        } catch (WriterException e) {
            e.printStackTrace();
        }
    }

    private void exibirImagemPerfil() {
        if (!TextUtils.isEmpty(imagemAluno)) {
            // O caminho da imagem deve ser o mesmo que você usou para salvar a imagem
            String caminhoImagem = getExternalFilesDir(Environment.DIRECTORY_PICTURES) + File.separator + imagemAluno;

            // Carregue a imagem do caminho e exiba-a no CircleImageView
            File imagemArquivo = new File(caminhoImagem);

            if (imagemArquivo.exists()) {
                Uri imagemUri = Uri.fromFile(imagemArquivo);
                fotoperfil.setImageURI(imagemUri);
            } else {
                Toast.makeText(this, "Imagem não encontrada", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Nome da imagem vazio", Toast.LENGTH_SHORT).show();
        }
    }

    public void validarPINOnClick(View view) {
        EditText edtNmbPIN = findViewById(R.id.edtNmbPIN);
        String enteredPin = edtNmbPIN.getText().toString();
        String currentDateTime = null; // Declare a variável antes de usá-la

        if (enteredPin.equals(generatedPin)) {
            // PIN válido, agora vamos passar o nome e o email do aluno
            Intent intent = new Intent(this, ResultadoActivity.class);

            // Insira o ID do aluno e o código PIN na tabela "pins" com a data e hora atuais
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            currentDateTime = dateFormat.format(new Date());
            String sql = "INSERT INTO pins (aluno_id, pin, data_escaneamento) VALUES (?, ?, ?)";
            bancoDados.execSQL(sql, new Object[]{idAluno, generatedPin, currentDateTime});

            // Passe os dados do aluno e a data/hora do escaneamento para a página de resultado
            intent.putExtra("idAluno", idAluno);
            intent.putExtra("nomeAluno", nomeAluno);
            intent.putExtra("emailAluno", emailAluno);
            intent.putExtra("dataEscaneamento", currentDateTime);
            intent.putExtra("imagemAluno", imagemAluno);

            startActivity(intent);
        } else {
            Toast.makeText(this, "PIN inválido", Toast.LENGTH_SHORT).show();
        }
    }
}
