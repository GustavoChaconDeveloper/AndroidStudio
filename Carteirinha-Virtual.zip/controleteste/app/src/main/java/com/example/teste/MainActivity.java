package com.example.teste;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    private SQLiteDatabase bancoDados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        criarBancoDados();
    }

    public void chamarTelaLogin(View view){
        Intent intent = new Intent(this, Login.class);
        startActivity(intent);
    }

    public void chamarTelaRegistro(View view){
        Intent intent = new Intent(this, Registro.class);
        startActivity(intent);
    }

    public void chamarTelaLista(View view){
        Intent intent = new Intent(this, ListaAlunos.class);
        startActivity(intent);
    }

    public void criarBancoDados() {
        try {
            bancoDados = openOrCreateDatabase("carteirinhabanco", MODE_PRIVATE, null);

            bancoDados.execSQL("CREATE TABLE IF NOT EXISTS alunos(" +
                    "id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT," +
                    "nome VARCHAR(255)," +
                    "email VARCHAR(255)," +
                    "senha VARCHAR," +
                    "curso VARCHAR(100)," +
                    "periodo VARCHAR(50)," +
                    "nome_imagem VARCHAR(255) DEFAULT NULL)");

            // Crie a tabela para armazenar os PINs de verificação
            bancoDados.execSQL("CREATE TABLE IF NOT EXISTS pins(" +
                    "id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT," +
                    "aluno_id INTEGER," +
                    "pin VARCHAR(6)," +
                    "data_escaneamento DATETIME, " + // Coluna para armazenar a data e hora do escaneamento
                    "FOREIGN KEY (aluno_id) REFERENCES alunos(id))");

            bancoDados.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



}
